
CreateTopologiesArguments = {0,2->1,ExcludeTopologies->{Snails,WFCorrectionCTs,TadpoleCTs},Adjacencies->{3,4},CTOrder->0};

InsertFieldsArguments = {{S[1],V[5]}->{V[5]},Model->"SMQCD",GenericModel->"Lorentz",InsertionLevel->{Particles},Restrictions->{ExcludeParticles->{S[2|3]},ExcludeFieldPoints->{FieldPoint[_][-F[4,{1,___}],F[3,{2,___}],S[3]],FieldPoint[_][-F[4,{1,___}],F[3,{2,___}],V[3]],FieldPoint[_][-F[4,{1,___}],F[3,{3,___}],S[3]],FieldPoint[_][-F[4,{1,___}],F[3,{3,___}],V[3]],FieldPoint[_][-F[4,{2,___}],F[3,{1,___}],S[3]],FieldPoint[_][-F[4,{2,___}],F[3,{1,___}],V[3]],FieldPoint[_][-F[4,{2,___}],F[3,{3,___}],S[3]],FieldPoint[_][-F[4,{2,___}],F[3,{3,___}],V[3]],FieldPoint[_][-F[4,{3,___}],F[3,{1,___}],S[3]],FieldPoint[_][-F[4,{3,___}],F[3,{1,___}],V[3]],FieldPoint[_][-F[4,{3,___}],F[3,{2,___}],S[3]],FieldPoint[_][-F[4,{3,___}],F[3,{2,___}],V[3]]}}};

FeynArtsDiagrams = TopologyList[Process->{S[1],V[5,{Index[Gluon,2]}]}->{V[5,{Index[Gluon,3]}]},Model->{"SMQCD"},GenericModel->{"Lorentz"},InsertionLevel->{Particles},ExcludeParticles->{S[2],-S[3],S[3]},ExcludeFieldPoints->{},LastSelections->{}][];
