
CreateTopologiesArguments = {0,2->1,ExcludeTopologies->{Snails,WFCorrectionCTs,TadpoleCTs},Adjacencies->{3,4},CTOrder->1,Adjacencies->{3}};

InsertFieldsArguments = {{F[3,{1}],-F[4,{3}]}->{-V[3]},Restrictions->{ExcludeFieldPoints->{}},Model->"SMQCDR2",GenericModel->"Lorentz",InsertionLevel->{Particles}};

FeynArtsDiagrams = TopologyList[Process->{F[3,{1,Index[Colour,1]}],-F[4,{3,Index[Colour,2]}]}->{-V[3]},Model->{"SMQCDR2"},GenericModel->{"Lorentz"},InsertionLevel->{Particles},ExcludeParticles->{},ExcludeFieldPoints->{},LastSelections->{}][Topology[1][Propagator[Incoming][Vertex[1][1],Vertex[3,1][4],Field[1]],Propagator[Incoming][Vertex[1][2],Vertex[3,1][4],Field[2]],Propagator[Outgoing][Vertex[1][3],Vertex[3,1][4],Field[3]]]->Insertions[Generic][FeynmanGraph[1,Generic==1][Field[1]->F[3,{1,Index[Colour,1]}],Field[2]->-F[4,{3,Index[Colour,2]}],Field[3]->V[3]]->Insertions[Particles][FeynmanGraph[1,Particles==1][Field[1]->F[3,{1,Index[Colour,1]}],Field[2]->-F[4,{3,Index[Colour,2]}],Field[3]->V[3]]]]];
